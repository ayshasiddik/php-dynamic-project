-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 19, 2022 at 07:20 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kufa`
--

-- --------------------------------------------------------

--
-- Table structure for table `abouts`
--

CREATE TABLE `abouts` (
  `id` int NOT NULL,
  `service_icon` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_value` int NOT NULL,
  `service_tittle` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_description` text COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `abouts`
--

INSERT INTO `abouts` (`id`, `service_icon`, `service_value`, `service_tittle`, `service_description`) VALUES
(1, 'fa-brands fa-html5', 90, 'HTML', '     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum, sed repudiandae odit deserunt, quas quibusdam necessitatibus nesciunt eligendi esse sit non reprehenderit quisquam asperiores maxime blanditiis culpa vitae velit. Numquam!    '),
(2, 'fa-brands fa-css3', 80, 'CSS', '        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum, sed repudiandae odit deserunt, quas quibusdam necessitatibus nesciunt eligendi esse sit non reprehenderit quisquam asperiores maxime blanditiis culpa vitae velit. Numquam!      '),
(3, 'fa-brands fa-php', 60, 'PHP', '     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum, sed repudiandae odit deserunt, quas quibusdam necessitatibus nesciunt eligendi esse sit non reprehenderit quisquam asperiores maxime blanditiis culpa vitae velit. Numquam!   '),
(4, 'fa-brands fa-laravel', 10, 'LARAVEL', '     Lorem ipsum dolor sit amet, consectetur adipisicing elit. Rerum, sed repudiandae odit deserunt, quasquibusdam necessitatibus nesciunt eligendi esse sit non reprehenderit quisquam asperiores maxime blanditiis culpa vitae velit. Numquam!   ');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int NOT NULL,
  `name` varchar(200) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `email` varchar(200) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `password` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `profile picture` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT 'demo.png',
  `phone_number` varchar(100) COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT '+88xxxxxxxxxxx',
  `address` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT 'update address',
  `office_address` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT 'update office address',
  `fblink` varchar(100) COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT 'https://www.facebook.com',
  `twlink` varchar(100) COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT 'https://twitter.com ',
  `inslink` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT ' https://www.instagram.com',
  `plink` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL DEFAULT ' https://pretestplus.co.uk'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `password`, `profile picture`, `phone_number`, `address`, `office_address`, `fblink`, `twlink`, `inslink`, `plink`) VALUES
(35, 'quxocemicy', 'kijyceku@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(37, 'vopolanug', 'qevaqodatu@mailinator.com', 'ac748cb38ff28d1ea98458b16695739d7e90f22d', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(42, 'cucefiru', 'gyla@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', '42.jpeg', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(45, 'qehujabol', 'semomijun@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(48, 'wifafyti', 'jugyp@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(75, 'jodihehyko', 'ruguqozoza@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(76, 'Avram Odom', 'velegesi@mailinator.com', 'd57d098a171e64bbb4ba87458f4ddd132636f388', '76.jpeg', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(77, 'bowydahyqy', 'jakysojuc@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(78, 'vezozonaso', 'wexihe@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(79, 'bycoxavo', 'lybosewi@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(80, 'newux', 'qyfanybe@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(81, 'bugumikepa', 'puqiby@mailinator.com', 'a0a16598af0eb7c49388ebec4fe5204141cd745a', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(82, 'zetitipavo', 'tizififaga@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', 'demo.png', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk'),
(83, 'zabokupi', 'cetuj@mailinator.com', 'fa832495588ed9fa80bb73838f7f557e5832d695', ' 83.jpeg', '+88xxxxxxxxxxx', 'example<address>', 'office<address>', 'https://www.facebook.com', 'https://twitter.com ', ' Login • Insthttps://www.instagram.com', ' Loginhttps://pretestplus.co.uk');

-- --------------------------------------------------------

--
-- Table structure for table `contactmails`
--

CREATE TABLE `contactmails` (
  `id` int NOT NULL,
  `name` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `email` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `massage` text COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `contactmails`
--

INSERT INTO `contactmails` (`id`, `name`, `email`, `massage`) VALUES
(17, 'Baker Jimenez', 'susunabos@mailinator.com', 'Nihil aut numquam co'),
(18, 'Yoko Sweeney', 'hefojaji@mailinator.com', 'Non natus aspernatur'),
(19, 'Melvin Palmer', 'nejepoq@mailinator.com', 'Nam doloremque asper'),
(20, 'Bert Browning', 'sujih@mailinator.com', 'Qui deleniti eum ali');

-- --------------------------------------------------------

--
-- Table structure for table `footerimages`
--

CREATE TABLE `footerimages` (
  `id` int NOT NULL,
  `imageone` varchar(100) COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `footerimages`
--

INSERT INTO `footerimages` (`id`, `imageone`) VALUES
(18, '1668451674.png'),
(19, '1668451579.png'),
(20, '1668451591.png'),
(21, '1668451604.png');

-- --------------------------------------------------------

--
-- Table structure for table `imageservices`
--

CREATE TABLE `imageservices` (
  `id` int NOT NULL,
  `service_tittle` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_heading` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_description` text COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `services_status` varchar(10) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_image` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `imageservices`
--

INSERT INTO `imageservices` (`id`, `service_tittle`, `service_heading`, `service_description`, `services_status`, `service_image`) VALUES
(10, 'Proident explicabo', 'Hic praesentium volu', '    In dolores magni ame', 'active', '1668749719.jpeg'),
(11, 'Tenetur laborum eos ', 'Ex aliquam aliquam q', 'Harum saepe est rer', 'active', '1668317527.jpeg'),
(12, 'Magnam suscipit ut c', 'Beatae ex itaque sun', ' Ipsam illum aliquip', 'active', '1668317554.jpeg'),
(13, 'Consectetur et debi', 'Nisi sed deleniti la', 'Nostrud voluptates s', 'active', '1668317589.jpeg'),
(14, 'Mollitia quia itaque', 'Officia pariatur Du', ' Non nostrum dolor si', 'active', '1668317874.jpeg'),
(15, 'Ullam laboriosam ea', 'Rem maiores magna re', ' Anim cupidatat reici', 'active', '1668317900.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int NOT NULL,
  `service_icon` varchar(100) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_tittle` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_description` text COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_status` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `service_icon`, `service_tittle`, `service_description`, `service_status`) VALUES
(11, 'fal fa-desktop', 'webdevelopment', '  amader desh ta sopno puri', 'active'),
(16, 'fa fa-address-card', 'Qui obcaecati eligen', '  Delectus recusandae', 'active'),
(21, 'fa fa-address-card', 'Consequuntur et quib', '  Quos molestias omnis', 'active'),
(22, 'fa fa-android', 'Doloribus dolore qui', '  Ipsum ullamco ut omn', 'active'),
(23, 'fa fa-angellist', 'Optio nesciunt omn', 'Earum magna voluptat', 'active'),
(24, 'fa fa-asl-interpreting', 'Corrupti delectus ', 'Vel tempore qui fug', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `servicestwoo`
--

CREATE TABLE `servicestwoo` (
  `id` int NOT NULL,
  `service_icon` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `service_value` int NOT NULL,
  `service_tittle` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `servicestwoo`
--

INSERT INTO `servicestwoo` (`id`, `service_icon`, `service_value`, `service_tittle`) VALUES
(3, 'fa fa-android', 300, 'Eos qui provident '),
(4, 'fa fa-bank', 400, 'Quod perferendis rep'),
(5, 'fa fa-apple', 500, 'Qui cupidatat illo m');

-- --------------------------------------------------------

--
-- Table structure for table `testimonialservices`
--

CREATE TABLE `testimonialservices` (
  `id` int NOT NULL,
  `p_image` varchar(70) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `comments` text COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `info_tiitle` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL,
  `info_subtitle` varchar(50) COLLATE utf8mb3_unicode_520_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_520_ci;

--
-- Dumping data for table `testimonialservices`
--

INSERT INTO `testimonialservices` (`id`, `p_image`, `comments`, `info_tiitle`, `info_subtitle`) VALUES
(3, '1668749839.jpeg', '   value=\"An event is a message sent by an object to signal the occur rence of an action. The action can causd user interaction such as a button click, or it can result\"', 'Harlik', 'dinajpur'),
(4, '1668375986.jpeg', '  An event is a message sent by an object to signal the occur rence of an action. The action can causd user interaction such as a button click, or it can result', 'lota', 'gazipur'),
(5, '1668376042.jpeg', '  An event is a message sent by an object to signal the occur rence of an action. The action can causd user interaction such as a button click, or it can resultt!', 'Fariha', 'pancogar');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `abouts`
--
ALTER TABLE `abouts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `contactmails`
--
ALTER TABLE `contactmails`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `footerimages`
--
ALTER TABLE `footerimages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imageservices`
--
ALTER TABLE `imageservices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `servicestwoo`
--
ALTER TABLE `servicestwoo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `testimonialservices`
--
ALTER TABLE `testimonialservices`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `abouts`
--
ALTER TABLE `abouts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `contactmails`
--
ALTER TABLE `contactmails`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `footerimages`
--
ALTER TABLE `footerimages`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `imageservices`
--
ALTER TABLE `imageservices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `servicestwoo`
--
ALTER TABLE `servicestwoo`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `testimonialservices`
--
ALTER TABLE `testimonialservices`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
